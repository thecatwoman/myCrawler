http://free-proxy.cz/en/

press Export IP:Port

copy to proxy.txt