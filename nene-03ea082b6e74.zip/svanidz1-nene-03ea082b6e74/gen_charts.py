import numpy as np
import matplotlib.pyplot as plt

d = {}

with open("crawl_time.txt","r") as f:
    for s in f.read().split("\n"):
        name,core,url,domain,thread,time = s.split(",")
        d[domain] = d.get(domain, {})
        d[domain][thread] = d[domain].get(thread, {})
        d[domain][thread][core] = d[domain][thread].get(core, {})
        d[domain][thread][core][name] = float(time)

dmns = list(d.keys())

update_plots = False

if True:
    for name in ['scrapy', 'mywebc']:
        # mywebc,1,http://cte.ibsu.edu.ge/,cte.ibsu.edu.ge,8,36.08
        # scrapy,4,http://iro.ibsu.edu.ge/,iro.ibsu.edu.ge,8,79.24
        n_groups = 3

        _sc1 = tuple(d[dmn]['16']['1'][name] for dmn in dmns)
        _sc2 = tuple(d[dmn]['16']['2'][name] for dmn in dmns)
        _sc4 = tuple(d[dmn]['16']['4'][name] for dmn in dmns)
        print(dmns, name)
        print(1, _sc1)
        print(2, _sc2)
        print(4, _sc4)

        fig, ax = plt.subplots()

        index = np.arange(n_groups)
        bar_width = 0.23

        opacity = 0.6
        error_config = {'ecolor': '0.3'}

        rects1 = plt.bar(index, _sc1, bar_width,
                        alpha=opacity,
                        color='b',
                        # yerr=std_men,
                        # error_kw=error_config,
                        label='1 core')

        rects2 = plt.bar(index + bar_width, _sc2, bar_width,
                        alpha=opacity,
                        color='r',
                        # yerr=std_women,
                        # error_kw=error_config,
                        label='2 core')
        
        rects3 = plt.bar(index + bar_width * 2, _sc4, bar_width,
                        alpha=opacity,
                        color='g',
                        # yerr=std_women,
                        # error_kw=error_config,
                        label='4 core')

        plt.xlabel('{0} on different cores'.format(name))
        plt.ylabel('Seconds')
        plt.title(name)
        # d[dmn]['8']['1']['mywebc'],d[dmn]['8']['2']['mywebc'],d[dmn]['8']['4']['mywebc'],
        #        d[dmn]['16']['1']['mywebc'],d[dmn]['16']['2']['mywebc'],d[dmn]['16']['4']['mywebc'])

        plt.xticks(index + bar_width / 2, (".".join(dmn.split(".")[:2]) for dmn in dmns))
        plt.legend()

        plt.tight_layout()
        if update_plots:
            plt.savefig('plts/{0}_cores_plt.png'.format(name))
        # print(d)



if False:
    dmns = list(d.keys())
    # nhmywebc,4,http://iro.ibsu.edu.ge/,iro.ibsu.edu.ge,8,29.29
    # nhmywebc,2,http://iro.ibsu.edu.ge/,iro.ibsu.edu.ge,8,27.47
    n_groups = 6

    _nhmy = tuple(d[dmn]['8'][c]['nhmywebc'] for c in ["2","4"] for dmn in dmns)
    _my = tuple(d[dmn]['8'][c]['mywebc'] for c in ["2","4"] for dmn in dmns)

    print(_nhmy)

    fig, ax = plt.subplots()

    index = np.arange(n_groups)
    bar_width = 0.35

    opacity = 0.6
    error_config = {'ecolor': '0.3'}

    rects1 = plt.bar(index, _nhmy, bar_width,
                    alpha=opacity,
                    color='b',
                    # yerr=std_men,
                    # error_kw=error_config,
                    label='NoHeadFilter')

    rects2 = plt.bar(index + bar_width, _my, bar_width,
                    alpha=opacity,
                    color='r',
                    # yerr=std_women,
                    # error_kw=error_config,
                    label='MyWebC')

    plt.xlabel('core-webpage')
    plt.ylabel('Seconds')
    plt.title("NoHeadFilter and MyWebC")
    # d[dmn]['8']['1']['mywebc'],d[dmn]['8']['2']['mywebc'],d[dmn]['8']['4']['mywebc'],
    #        d[dmn]['16']['1']['mywebc'],d[dmn]['16']['2']['mywebc'],d[dmn]['16']['4']['mywebc'])

    plt.xticks(index + bar_width / 2, (c+"-"+".".join(dmn.split(".")[:2]) for c in ["2","4"] for dmn in dmns))
    plt.legend()

    plt.tight_layout()
    if update_plots:
        plt.savefig('plts/no_head_plt.png')
    # print(d)

if False:
    # mywebc,1,http://cte.ibsu.edu.ge/,cte.ibsu.edu.ge,8,36.08
    # scrapy,4,http://iro.ibsu.edu.ge/,iro.ibsu.edu.ge,8,79.24
    dmns = list(d.keys())
    n_groups = 6

    _sc = tuple(d[dmn]['8'][c]['scrapy'] for c in ["2","4"] for dmn in dmns)
    _nhmy = tuple(d[dmn]['8'][c]['nhmywebc'] for c in ["2","4"] for dmn in dmns)
    _my = tuple(d[dmn]['8'][c]['mywebc'] for c in ["2","4"] for dmn in dmns)


    fig, ax = plt.subplots()

    index = np.arange(n_groups)
    bar_width = 0.23

    opacity = 0.6
    error_config = {'ecolor': '0.3'}

    rects1 = plt.bar(index, _sc, bar_width,
                    alpha=opacity,
                    color='b',
                    # yerr=std_men,
                    # error_kw=error_config,
                    label='Scrapy')

    rects2 = plt.bar(index + bar_width, _nhmy, bar_width,
                    alpha=opacity,
                    color='r',
                    # yerr=std_women,
                    # error_kw=error_config,
                    label='NoHeadFilter')
    
    rects3 = plt.bar(index + bar_width * 2, _my, bar_width,
                    alpha=opacity,
                    color='g',
                    # yerr=std_women,
                    # error_kw=error_config,
                    label='MyWebC')

    plt.xlabel('core-webpage')
    plt.ylabel('Seconds')
    plt.title('Scrapy, NoHeadFilter and MyWebC')
    # d[dmn]['8']['1']['mywebc'],d[dmn]['8']['2']['mywebc'],d[dmn]['8']['4']['mywebc'],
    #        d[dmn]['16']['1']['mywebc'],d[dmn]['16']['2']['mywebc'],d[dmn]['16']['4']['mywebc'])

    plt.xticks(index + bar_width / 2, (c+"-"+".".join(dmn.split(".")[:2]) for c in ["2","4"] for dmn in dmns))
    plt.legend()

    plt.tight_layout()

    if update_plots:
        plt.savefig('plts/scrapt_nhmywc_mywc.png'.format(name))
    # print(d)