import requests, os, json, threading, random, time
from lxml import html
from urllib.parse import urljoin, urlunparse, urlparse
import urllib.robotparser
import multiprocessing 


class Spider:
    def __init__(self, crawler = None, name = "spider"):
        self.name = name
        self.crawler = crawler
        self.robot_test = None
        self.threads = []
        self.cores = 4
        self.delay = 1 if crawler.auto_throttle else 0
        self.last_request_time = 0
        self.lock_delay = threading.Lock()
        self.parse_data_tasks = multiprocessing.Queue()
        self.parse_data_processes = [
            multiprocessing.Process(target=self.parse_data, args=(self.parse_data_tasks, self.crawler.lock_ofile)) for i in range(self.cores)]
        if self.crawler.consider_robot:
            self.robot_test = {}
            for d in self.crawler.domains:
                self.robot_test[d] = urllib.robotparser.RobotFileParser()
                self.robot_test[d].set_url(urlunparse(("http", d, "robots.txt","","","")))
                self.robot_test[d].read()
    

    def start(self, conc_request = 1):
        for i in range(self.cores):
            self.parse_data_processes[i].start()

        while not self.crawler.q.empty() or len(self.threads) > 0:
            ind = 0
            while len(self.threads) > ind and not self.threads[ind].is_alive():
                ind += 1
            self.threads = self.threads[ind:]
            if not self.crawler.q.empty() and len(self.threads) < 2 * conc_request:
                time_passed = time.time() - self.last_request_time
                if time_passed < self.delay / conc_request:
                    time.sleep(self.delay / conc_request - time_passed)
                with self.lock_delay:
                    self.last_request_time = time.time()
                url = self.crawler.q.get()
                self.threads.append(threading.Thread(target=self.crawl_url, args=(url,ind)))
                self.threads[-1].start()
            # print(len(self.threads), self.parse_data_tasks.empty())
            time.sleep(0.2)
        
        self.parse_data_status = 0
        for _ in range(self.cores):
            self.parse_data_tasks.put(None)
        for i in range(self.cores):
            self.parse_data_processes[i].join()


    
    def crawl_url(self, url, ind):
        print(url)
        # try 3 times to download page
        for _ in range(3):
            try:
                req = {
                    'url': url,
                    'headers': {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36'},
                }

                if len(self.crawler.proxies) > 0:
                    rand_proxy = random.choice(self.crawler.proxies)
                    req['proxies'] = { "http" : rand_proxy, "https" : rand_proxy }
                
                # check if url is website
                r = requests.head(**req)
                if "text/html" not in r.headers["content-type"]:
                    print("Not website:", url)
                    return

                request_time = time.time()

                r = requests.get(**req)

                request_delay = time.time() - request_time

                if r.status_code == 200:

                    if self.crawler.auto_throttle:
                        with self.lock_delay:
                            self.delay = (self.delay * 9 + request_delay) / 10

                    links = self.parse(response=r, url=url)

                    with self.crawler.lock_queue:
                        for link in links:
                            if self.crawler.url_from.get(link) == None:
                                self.crawler.url_from[link] = url
                                self.crawler.q.put(link)
                
                break
            except:
                pass


    def parse(self, response, url):
        
        tree = html.fromstring(response.content)
        
        with self.crawler.lock_queue:
            url_from = self.crawler.url_from[url]
        
        self.parse_data_tasks.put((response, url, url_from))

        links = tree.xpath('//a/@href')

        links = [urljoin(response.url, l) for l in links]
        #domain filter
        links = [l for l in links if any(d in urlparse(l).netloc for d in self.crawler.domains)]
        #http and extra symbolos
        links = [l.replace("https://","http://").rstrip("/?#") for l in links ]
        #robot filter
        if self.crawler.consider_robot:
            links = [l for l in links if any(
                        d in urlparse(l).netloc and self.robot_test[d].can_fetch("*", l) for d in self.crawler.domains
            )]
        return links
    

    def parse_data(self, q, lock_file):
        while True:
            try:
                task = q.get()
                if task == None:
                    return 
                response, url, url_from = task
                print("111", url)
                tree = html.fromstring(response.content)

                data = {
                    'from' : url_from,
                    'url' : url,
                    'redirected_url' : response.url
                }

                for name, xpath, count in self.crawler.data_to_parse:
                    d = tree.xpath(xpath)
                    if count == 0:
                        count = len(d)
                    data[name] = d[:count]

                data = json.dumps(data)
                with lock_file:
                    with open(self.crawler.save_file, "a+") as f:
                        f.write("\t{0},\n".format(data))
            except:
                time.sleep(0.5)



