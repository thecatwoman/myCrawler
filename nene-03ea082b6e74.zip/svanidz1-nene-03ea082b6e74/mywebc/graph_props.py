import json, os, re
import numpy as np
from urllib.parse import urljoin, urlunparse, urlparse
import matplotlib.pyplot as plt

domains = [ "cte.ibsu.edu.ge" ]
json_file = "cte_full.json"

def load_graph(json_load):
    G = {}
    n_edges = 0
    for data in json_load:
        for l in data.get("links",[]):
            link  = urljoin(data["url"], l)
            if any(d in urlparse(link).netloc for d in domains):
                url = data["url"].replace("https://","http://").rstrip("/?#")
                link = link.replace("https://","http://").rstrip("/?#")
                url = re.sub('/index.php$', '', url)
                link = re.sub('/index.php$', '', link)
                G[data["url"]] = G.get(data["url"],[]) + [link]
                n_edges += 1
    return G, n_edges

def bfs(s,G):
    inf = 10**10
    dis = { s : 0}
    q, ind = [s], 0
    while ind < len(q):
        x = q[ind]
        ind += 1
        for y in G.get(x, []):
            if dis.get(y, inf) > dis[x] + 1:
                dis[y] = dis[x] + 1
                q += [y]
    return q, dis

def calc_con_comp(G):
    cc = 0
    f = set()
    for s in G.keys():
        if s not in f:
            q, _ = bfs(s, G)
            cc += 1
            for x in q:
                f.add(x)
    return cc

def calc_diameter(G):
    # BFS from each start and compute maximum distance
    d = 0
    for s in G.keys():
        q, dis = bfs(s, G)
        d = max(d, dis[q[-1]])
    return d


def calc_cc(G):
    total_open_tr = 0
    total_close_tr = 0

    local_cc = {}

    for s in G.keys():
        close_tr = 0
        open_tr = 0
        for x in G[s]:
            for y in G[s]:
                if y in G[x]:
                    close_tr += 1
                else:
                    open_tr += 1
        local_cc[s] =  close_tr / max(open_tr + close_tr, 1)
        total_close_tr += close_tr
        total_open_tr += open_tr
        
    global_cc = total_close_tr / max(total_open_tr + total_close_tr, 1)
    return global_cc, local_cc




if __name__ == "__main__":

    json_file =  open(os.path.dirname(os.path.realpath(__file__)) + "/" + json_file, "r")
      
    G, n_edges = load_graph(json.load(json_file))

    n_nodes = len(G.keys())

    undirected_G = {}
    for x in G.keys():
        for y in G[x]: 
            undirected_G[x] = undirected_G.get(x, set())
            undirected_G[y] = undirected_G.get(y, set())
            undirected_G[x].add(y)
            undirected_G[y].add(x)
    print("Start")

    con_comp = calc_con_comp(undirected_G)
    print("Connected Components:", con_comp)

    diameter = calc_diameter(G)
    print("Diameter:", diameter)
    global_cc, local_cc = calc_cc(undirected_G)
    print("Global Clustering Coefficient:", global_cc)

    local_cc = np.array(list(local_cc.values()))

    print("Local Clustering Coefficient:")
    print("\t","Mean",np.mean(local_cc))
    print("\t","Std",np.std(local_cc))
    plt.hist(local_cc)
    plt.savefig('graph_props/local_cc.png')

    f = open("graph_props/props.txt","w")

    f.write("Nodes: {0}\n".format(n_nodes))
    f.write("Edges: {0}\n".format(n_edges))
    f.write("Connected Components: {0}\n".format(con_comp))
    f.write("Diameter: {0}\n".format(diameter))
    f.write("Global Clustering Coefficient: {0:.5f}\n".format(global_cc))
    f.write("Local Clustering Coefficient:\n")
    f.write("\tMean {0:.5f}\n".format(np.mean(local_cc)))
    f.write("\tStd {0:.5f}\n".format(np.std(local_cc)))




    
