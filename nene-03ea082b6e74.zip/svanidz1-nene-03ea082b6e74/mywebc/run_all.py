import time, os
from crawler import Crawler

if __name__ == "__main__":
    cores = 4
    file_name = "data_mywebc_{0}.txt".format(cores)

    concurrent_requests = [4,8,16]

    sites = [
        (["http://iro.ibsu.edu.ge/"], ["iro.ibsu.edu.ge"]),
        (["http://law.ibsu.edu.ge/"], ["law.ibsu.edu.ge"]),
        (["http://cte.ibsu.edu.ge/"], ["cte.ibsu.edu.ge"]),
        (["http://bm.ibsu.edu.ge/"], ["bm.ibsu.edu.ge"]),
        (["http://ibsu.edu.ge/"], ["ibsu.edu.ge"]),
    ]

    for _ in range(5):
        for cr in concurrent_requests:
            for start_urls, allowed_domains in sites:
                _config = {
                    "start_urls": start_urls,
                    "domains": allowed_domains,
                    "save_file": "test.json",
                    "conc_request": cr,
                    "data_to_parse": [ ["links", "//a/@href", 0] ],
                    "use_proxy": 0,
                    "auto_throttle": 1
                }
                print(start_urls)

                c = Crawler(**_config)

                tm = c.start()
                open(file_name,"a+").write("{0},{1},{2},{3},{4},{5:.2f}\n".format("mywebc",cores,start_urls[0],allowed_domains[0],cr,tm))
                
                time.sleep(5)
                
