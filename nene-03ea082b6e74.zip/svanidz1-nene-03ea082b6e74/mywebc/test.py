from lxml import html
import requests
from urllib.parse import urljoin
import multiprocessing
import psutil

print(multiprocessing.cpu_count())
print(psutil.cpu_count())

proxies = {
 "http": "165.22.41.190:80",
 "https": "165.22.41.190:80",
}
headers = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36'}
r = requests.get("http://ibsu.edu.ge/", headers=headers, proxies=proxies)

tree = html.fromstring(r.content)
links = tree.xpath('//a/@href')

print(tree.xpath('//title/text()')[0])

print(r.status_code)

print(r.url)
for l in links:
    print(l, "\t", urljoin(r.url, l))



import urllib.robotparser
rp = urllib.robotparser.RobotFileParser()
rp.set_url("http://www.musi-cal.com/robots.txt")
rp.read()
rrate = rp.request_rate("*")
rrate.requests

rrate.seconds

rp.crawl_delay("*")

rp.can_fetch("*", "http://www.musi-cal.com/cgi-bin/search?city=San+Francisco")

rp.can_fetch("*", "http://www.musi-cal.com/")


# 'links' :  list(set(urljoin(response.url, l) for l in tree.xpath('//a/@href')))

["title", "//title/text()", 1] 