import json,os,re
json_file =  open(os.path.dirname(os.path.realpath(__file__)) + "/cte2.json", "r")

domain = "cte.ibsu.edu.ge/"

def filter(x):
    x = "".join(x.split(domain)[1:])
    if len(x) == 0:
        x = "start"
    a = ""
    last = 0
    for i in x:
        if i.isalnum():
            a += i
            last = 0
        else:
            if last == 0:
                a += "_"
                last = 1
    return a.strip("_")
    

f = open("graph_props/graph.txt","w")

f.write("""
digraph G {
node [style=filled,width=2,height=2];
""")

s = set()

for data in json.load(json_file):
    fr = data["from"].replace("https://","http://").rstrip("/?#")
    to = data['url'].replace("https://","http://").rstrip("/?#")
    fr = re.sub('/index.php$', '', fr)
    to = re.sub('/index.php$', '', to)
    x,y = filter(fr), filter(to)
    if y not in s:
        f.write("{0} -> {1} [ weight=1, penwidth=3];\n".format(x,y))
        s.add(y)
f.write("}")