from spider import Spider
import queue, os, threading, sys, json, time, requests
import multiprocessing 

class Crawler:
    def __init__(self, start_urls, domains, save_file = "data.json", 
                 conc_request = 1, data_to_parse = [], consider_robot = True, 
                 use_proxy = False, auto_throttle = False):
        self.start_urls = start_urls
        self.domains = domains
        self.consider_robot = consider_robot
        self.save_file = save_file
        self.data_to_parse = data_to_parse
        self.conc_request = conc_request
        self.lock_queue = threading.Lock()
        self.lock_ofile = multiprocessing.Lock()
        self.count_parsed_pages = 0
        self.auto_throttle = auto_throttle
        self.proxies = []
        if use_proxy:
            self.proxies = open(os.path.dirname(os.path.realpath(__file__)) + "/../proxy.txt","r").read().split()
            print(self.proxies)

        self.url_from = {}
        self.q = queue.Queue()
        for url in self.start_urls:
            self.q.put(url)
            self.url_from[url] = "START"        
        
    

    def start(self):
        with open(self.save_file, "w") as f:
            f.write("[\n")
        
        self.spider = Spider(crawler = self, name="spider")

        start_time = time.time()
        self.spider.start(conc_request = self.conc_request)
        end_time = time.time()

        with open(self.save_file, "a+") as f:
            f.write("]\n")
        
        return end_time - start_time




if __name__ == "__main__":

    _config = open(sys.argv[1], "r").read()
    _config = json.loads(_config)

    c = Crawler(**_config)

    start_ctime = time.ctime()
    start_time = time.time()

    try:
        c.start()
    except:
        print("Error")
    
    end_time = time.time()

    print("time: {0:.2f} seconds\npages: {1}\n".format(end_time - start_time, c.count_parsed_pages))

    stat = "{0} - {1}.  time: {2:.2f} seconds.  pages: {3}.\n".format(
        " ".join(sys.argv),
        start_ctime,
        end_time - start_time,
        c.count_parsed_pages)
    open("time.txt", "a").write(stat)


    

    