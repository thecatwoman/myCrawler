# -*- coding: utf-8 -*-
import scrapy, random, os
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule
import requests as myreqs


# class ProxyProvider:
#     def __init__(self):
#         self.proxies = open(os.path.dirname(os.path.realpath(__file__)) + "/../../../proxy.txt","r").read().split()
#         print(self.proxies)

#     def get_proxy(self):
#         return random.choice(self.proxies)

# pp = ProxyProvider()

class MainSpider(CrawlSpider):
    name = 'main'
    
    # allowed_domains = ['cte.ibsu.edu.ge']
    # start_urls = ['http://cte.ibsu.edu.ge/en']

    rules = (
        Rule(LinkExtractor(), callback='parse_item', follow=True),
    )


    def parse_item(self, response):
        item = {
            'url' : response.url,
            'links' : response.xpath('//a/@href').getall(),
            # 'title' : response.xpath('//title/text()').get(),
        }
        return item
