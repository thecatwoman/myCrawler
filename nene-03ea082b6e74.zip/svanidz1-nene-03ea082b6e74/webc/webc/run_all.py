import time, os

if __name__ == "__main__":

    concurrent_requests = [4,8,16]

    for _ in range(5):
        sites = [
            (["http://iro.ibsu.edu.ge/"], ["iro.ibsu.edu.ge"]),
            (["http://law.ibsu.edu.ge/"], ["law.ibsu.edu.ge"]),
            (["http://cte.ibsu.edu.ge/"], ["cte.ibsu.edu.ge"]),
            (["http://bm.ibsu.edu.ge/"], ["bm.ibsu.edu.ge"]),
            (["http://ibsu.edu.ge/"], ["ibsu.edu.ge"]),
        ]

        for cr in concurrent_requests:
            for start_urls, allowed_domains in sites:
                cmnd = "python3 run_crawler_cmd.py {0} {1} {2}".format(start_urls[0], allowed_domains[0], cr)
                print(cmnd)
                os.system(cmnd)
                time.sleep(5)
                
