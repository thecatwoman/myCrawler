import time
from spiders.main import MainSpider
from scrapy.crawler import CrawlerProcess
from scrapy.utils.project import get_project_settings
import sys, logging

if __name__ == "__main__":
    cores = 4
    file_name = "data_scrapy_{0}.txt".format(cores)
    logging.getLogger('scrapy').propagate = False
    start_url, allowed_domain, concurrent_requests = sys.argv[1], sys.argv[2], int(sys.argv[3])
    print(start_url)
    settings = get_project_settings()
    settings.set('USER_AGENT', "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.75 Safari/537.36")
    settings.set('CONCURRENT_REQUESTS_PER_DOMAIN', concurrent_requests)
    settings.set('AUTOTHROTTLE_ENABLED', True)    
    process = CrawlerProcess(settings)
    crawler = process.create_crawler(MainSpider)
    process.crawl(crawler, start_urls=[start_url], allowed_domains=[allowed_domain])
    process.start() # block until finished 
    print(crawler.stats.get_stats())
    tm = crawler.stats.get_stats()["elapsed_time_seconds"]
    open(file_name,"a+").write("{0},{1},{2},{3},{4},{5:.2f}\n".format("scrapy",cores,start_url,allowed_domain,concurrent_requests,tm))